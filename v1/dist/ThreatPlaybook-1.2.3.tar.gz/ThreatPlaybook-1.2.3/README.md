# ThreatPlaybook
A (relatively) Unopinionated framework that faciliates Threat Modeling as Code married with Application Security Automation on a single Fabric

> Catch up with us at BlackHat USA 2018 at Arsenal between 4pm and 5:20pm on 8th Aug 2018

[![Black Hat Arsenal USA](https://rawgit.com/toolswatch/badges/master/arsenal/usa/2018.svg)](https://www.blackhat.com/us-18/arsenal/schedule/index.html#threatplaybook-11697)
[![Build Status](https://travis-ci.org/we45/ThreatPlaybook.svg?branch=master)](https://travis-ci.org/we45/ThreatPlaybook)

![](tp_logo.png)

## Brought to you proudly by
![](we45logo.jpg)

## Documentation and Installation Instructions
**We highly encourage you to go over the documentation for better understanding how you can leverage/contribute to ThreatPlaybook**

[ThreatPlaybook Documentation - Gitbook](https://we45.gitbook.io/threatplaybook/)

Keyword Documentation for this library is [here](https://s3.amazonaws.com/threat-playbook/keywords.html)